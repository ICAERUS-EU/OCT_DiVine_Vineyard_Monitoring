import os, json, cv2, numpy as np
from PIL import Image
from glob import glob

# Set your directories
json_dir = '...winary_labels'         # Folder containing *_D.json files (extension *_D in the file name is generated for DJI Mavic 3 RGB images)
image_dir = '...clean RGB images'       # Folder containing .jpg images
output_dir = '...output files'          # Output folder for labeled .jpg images
os.makedirs(output_dir, exist_ok=True)

# Labels to extract
target_labels = {"eska", "meska", "ostalo"} # esca - Esca disease, mesca - Maybe Esca, ostalo - other

# Label colors - define color for each label
label_colors = {
    "eska": (255, 0, 0),
    "meska": (0, 0, 255),
    "ostalo": (0, 255, 0),
}

# Helper to find matching image
def find_image(image_filename):
    base, _ = os.path.splitext(image_filename)
    for ext in ['.JPG', '.jpg', '.TIF', '.tif']:
        path = os.path.join(image_dir, base + ext)
        if os.path.exists(path):
            return path
    return None

# Process JSON files
for json_path in glob(os.path.join(json_dir, "*_D.JSON")):
    with open(json_path, encoding="utf-8") as f:
        data = json.load(f)

    image_path = find_image(data.get("imagePath", ""))
    if not image_path:
        print(f"Image not found for {json_path}")
        continue

    # Read EXIF from original image using PIL
    try:
        pil_image = Image.open(image_path)
        exif_data = pil_image.info.get("exif", None)
    except Exception as e:
        print(f"Could not read EXIF: {e}")
        exif_data = None

    # Load image with OpenCV
    image = cv2.imread(image_path)
    if image is None:
        print(f"Could not load image: {image_path}")
        continue

    # Draw bounding boxes
    for shape in data.get("shapes", []):
        label = shape.get("label", "").lower()
        if label not in label_colors:
            continue

        points = shape.get("points", [])
        if len(points) != 2:
            continue

        pt1 = tuple(map(int, points[0]))
        pt2 = tuple(map(int, points[1]))
        color = label_colors[label]

        # Draw filled bounding box
        cv2.rectangle(image, pt1, pt2, color, thickness=-1)

    # Convert OpenCV (BGR) to PIL (RGB)
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    output_pil = Image.fromarray(image_rgb)

    # Save with EXIF
    output_path = os.path.join(output_dir, os.path.basename(image_path))
    if exif_data:
        output_pil.save(output_path, format="JPEG", exif=exif_data)
    else:
        output_pil.save(output_path, format="JPEG")

    print(f"Saved: {output_path}")
