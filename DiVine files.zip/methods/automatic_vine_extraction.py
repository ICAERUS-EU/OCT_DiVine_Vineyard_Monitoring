import cv2
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from PIL import Image

# INPUT PARAMETERS 
image_path = "...2024_Plavinci_Orthomosaic.rgb.TIF"  # Replace with your map
resize_factor = 0.2                 # Scale down for display
vine_spacing_px = 121               # pixels between vines in a row
row_spacing_px = 44                 # pixels between rows

# Load and resize image
original_img = cv2.imread(image_path, cv2.IMREAD_COLOR)
if original_img is None:
    raise FileNotFoundError(f"Image not found: {image_path}")

resized_img = cv2.resize(original_img, (0, 0), fx=resize_factor, fy=resize_factor)
clone_for_drawing = resized_img.copy()

# Click 4 corners of vineyard 
clicked_points = []

def click_event(event, x, y, flags, param):
    if event == cv2.EVENT_LBUTTONDOWN and len(clicked_points) < 4:
        clicked_points.append((x, y))
        cv2.circle(clone_for_drawing, (x, y), 5, (0, 0, 255), -1)
        cv2.imshow("Click 4 Vineyard Corners", clone_for_drawing)

cv2.imshow("Click 4 Vineyard Corners", clone_for_drawing)
cv2.setMouseCallback("Click 4 Vineyard Corners", click_event)

print("Click 4 points (TL, TR, BR, BL) on the image window...")

cv2.waitKey(0)
cv2.destroyAllWindows()

if len(clicked_points) != 4:
    raise ValueError("You must click exactly 4 points.")

# Generate vine grid from 4 corners 
# Convert to numpy array, scale back to original size
clicked_points = np.array(clicked_points, dtype=np.float32) / resize_factor

TL, TR, BR, BL = clicked_points

# Calculate row and vine vectors
row_vector = (BL - TL) / np.linalg.norm(BL - TL)
vine_vector = (TR - TL) / np.linalg.norm(TR - TL)

# Calculate number of vines and rows (approx)
vine_length = np.linalg.norm(TR - TL)
row_length = np.linalg.norm(BL - TL)

num_vines = int(vine_length // vine_spacing_px)
num_rows = int(row_length // row_spacing_px)

# Generate grid points
grid_image = original_img.copy()
for i in range(num_rows + 1):
    for j in range(num_vines + 1):
        start = TL + row_vector * i * row_spacing_px + vine_vector * j * vine_spacing_px
        center = tuple(map(int, start))
        cv2.circle(grid_image, center, 5, (0, 255, 0), -1)

# Show and optionally save the result
cv2.imshow("Vineyard Grid", cv2.resize(grid_image, (0, 0), fx=resize_factor, fy=resize_factor))
cv2.waitKey(0)
cv2.destroyAllWindows()

# Optional save
out_path = "vineyard_with_grid.tif"
Image.fromarray(cv2.cvtColor(grid_image, cv2.COLOR_BGR2RGB)).save(out_path)
print(f"Grid saved as: {out_path}")

