import cv2
import numpy as np
from PIL import Image

# CONFIG 
map_path = "...2024_07_NIR_Plavinci_30m_bl.rgb.tif"
mask_path = "...Plavinci_vine_mask_40px.tif" # Binary mask (255 = vine box, 0 = background)
output_path = "vineyard_only_vines.tif"

# LOAD IMAGES
# Load the vineyard map (as color)
map_image = cv2.imread(map_path, cv2.IMREAD_COLOR)
if map_image is None:
    raise FileNotFoundError(f"Could not load map: {map_path}")

# Load the mask (grayscale)
mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
if mask is None:
    raise FileNotFoundError(f"Could not load mask: {mask_path}")

# SIZE CHECK
if map_image.shape[:2] != mask.shape:
    raise ValueError("Map and mask must be the same dimensions!")

# APPLY MASK 
# Optional: make 3-channel mask
mask_3ch = cv2.merge([mask, mask, mask])

# Apply mask using bitwise AND
masked_result = cv2.bitwise_and(map_image, mask_3ch)

# SAVE RESULT 
# Save with PIL to preserve TIF format
Image.fromarray(cv2.cvtColor(masked_result, cv2.COLOR_BGR2RGB)).save(output_path)
print(f"Masked vineyard saved to: {output_path}")
