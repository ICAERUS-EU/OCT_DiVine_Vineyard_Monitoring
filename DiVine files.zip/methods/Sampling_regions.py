import cv2
import numpy as np
# import torch
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from scipy.ndimage import label
import rasterio
import os
from skimage.measure import label

# Load the image 
image_path = "...Path to the vegetation index map" # here, you change the path toward your vegetation index map

image_full = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
if image_full is None:
    raise FileNotFoundError("Image not found.")

image_full = image_full.astype(np.float32) / 255.0


# ROI Selection (scaled) 
scale_factor = 0.125
image_small = cv2.resize(image_full, (0, 0), fx=scale_factor, fy=scale_factor, interpolation=cv2.INTER_AREA)

roi_points = []
def click_event(event, x, y, flags, param):
    if event == cv2.EVENT_LBUTTONDOWN:
        roi_points.append((x, y))
        temp_img = image_small.copy()
        temp_img = cv2.cvtColor(temp_img, cv2.COLOR_GRAY2BGR)
        cv2.polylines(temp_img, [np.array(roi_points, np.int32)], isClosed=True, color=(0, 255, 0), thickness=1)
        cv2.imshow("Select ROI (ESC to finish)", temp_img)

temp_img = cv2.cvtColor(image_small, cv2.COLOR_GRAY2BGR)
cv2.imshow("Select ROI (ESC to finish)", temp_img)
cv2.setMouseCallback("Select ROI (ESC to finish)", click_event)
cv2.waitKey(0)
cv2.destroyAllWindows()

# Scale ROI back to full size
roi_points_scaled = [(int(x / scale_factor), int(y / scale_factor)) for (x, y) in roi_points]

# Create ROI Mask 
mask = np.zeros_like(image_full, dtype=np.uint8)
cv2.fillPoly(mask, [np.array(roi_points_scaled, np.int32)], 1)

# Extract ROI Values 
roi_values = image_full[mask == 1].reshape(-1, 1)

# KMeans clustering (FAST) 
k = 4
kmeans = KMeans(n_clusters=k, n_init=3, random_state=42)
labels = kmeans.fit_predict(roi_values)

label_map = np.zeros_like(image_full, dtype=np.uint8)
coords = np.column_stack(np.where(mask == 1))
for idx, (y, x) in enumerate(coords):
    label_map[y, x] = labels[idx] + 1

# Remove small fragments (Morphological Filtering) 
zone_map = np.zeros_like(image_full, dtype=np.uint8)
for i in range(1, k + 1):
    zone = (label_map == i).astype(np.uint8) * 255
    # Morphology (opening + closing) to merge small regions
    zone = cv2.morphologyEx(zone, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    zone = cv2.morphologyEx(zone, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
    zone_map[zone > 0] = i

# Visualize 
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
plt.imshow(image_full, cmap='RdYlGn')
plt.title("Vegetation Index")
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(zone_map, cmap='tab10')
plt.title("Contiguous Sampling Zones (Fast)")
plt.axis('off')
plt.tight_layout()
plt.show()

# Visualize each cluster separately 
plt.figure(figsize=(15, 6))
for i in range(1, k + 1):
    cluster_mask = (zone_map == i).astype(np.uint8) * 255
    plt.subplot(2, (k + 1) // 2, i)
    plt.imshow(cluster_mask, cmap='gray')
    plt.title(f"Cluster {i}")
    plt.axis('off')

plt.suptitle("Individual Sampling Zones (Masks)")
plt.tight_layout()
plt.show()

# Load RGB orthophoto from .tif 

orthophoto_path = "TIF file of the orthophoto image"  # <- update this path
with rasterio.open(orthophoto_path) as src_rgb:
    orthophoto = src_rgb.read([1, 2, 3]).transpose(1, 2, 0).astype(np.float32)
    orthophoto = (orthophoto - orthophoto.min()) / (orthophoto.max() - orthophoto.min())  # normalize to [0,1]


# Assumptions:
# - `label_map` contains cluster labels (1 to k)
# - `orthophoto_uint8` is the RGB base image already resized to match `label_map`
# - You want cluster pixels red and background transparent

k = label_map.max()  # Number of clusters
output_dir = "cluster_outputs"
os.makedirs(output_dir, exist_ok=True)

for cluster_id in range(1, k + 1):
    # Create mask for this cluster
    mask = (label_map == cluster_id).astype(np.uint8)

    # Create empty RGBA image
    h, w = mask.shape
    cluster_rgba = np.zeros((h, w, 4), dtype=np.uint8)

    # Set red color where mask is 1
    cluster_rgba[:, :, 0] = mask * 255   # Red
    cluster_rgba[:, :, 3] = mask * 255   # Alpha

    # Save to file
    filename = os.path.join(output_dir, f"cluster_{cluster_id}.png")
    cv2.imwrite(filename, cluster_rgba)

print(f"Saved {k} transparent cluster masks in red to '{output_dir}' folder.")

#################################
print("Unique labels inside ROI:", np.unique(label_map[mask == 1]))

# Show only selected cluster!
cluster_id = 3
patch_size = 1500   # size of the sampling region
thickness = 8

# MASK for selected cluster inside ROI 
cluster_mask = ((label_map == cluster_id) & (mask == 1)).astype(np.uint8)

plt.imshow(cluster_mask, cmap='gray')
plt.title(f"Cluster {cluster_id} Mask in ROI")
plt.axis('off')
plt.show()

# SLIDING WINDOW to count cluster pixels in ROI 
h, w = cluster_mask.shape
counts = []

for y in range(0, h - patch_size + 1, patch_size):
    for x in range(0, w - patch_size + 1, patch_size):
        patch_roi = mask[y:y + patch_size, x:x + patch_size]
        if np.all(patch_roi == 1):  # Fully inside ROI
            patch = cluster_mask[y:y + patch_size, x:x + patch_size]
            count = np.sum(patch)
            counts.append((count, (x, y)))

# SORT PATCHES 
counts_sorted = sorted(counts, key=lambda x: x[0], reverse=True)

# SELECT 2 most + 2 least populated patches (non-overlapping) 
selected = []
used = []

def overlaps(a, b):
    ax, ay = a
    bx, by = b
    return not (ax + patch_size <= bx or bx + patch_size <= ax or ay + patch_size <= by or by + patch_size <= ay)

for count, pos in counts_sorted:
    if all(not overlaps(pos, u) for u in used):
        selected.append((pos, 'most'))
        used.append(pos)
    if len([s for s in selected if s[1] == 'most']) >= 2:
        break

for count, pos in counts_sorted[::-1]:
    if all(not overlaps(pos, u) for u in used):
        selected.append((pos, 'least'))
        used.append(pos)
    if len([s for s in selected if s[1] == 'least']) >= 2:
        break

# Orthophoto overlapping

cluster_colors = {
    0: (255, 0, 0),    # Red
    1: (0, 255, 0),    # Green
    2: (0, 0, 255),    # Blue
}
alpha = 0.5  # Transparency for overlay

# Resize orthophoto to match NDVI map (if needed)
ndvi_h, ndvi_w = image_full.shape
ortho_resized = cv2.resize(orthophoto, (ndvi_w, ndvi_h), interpolation=cv2.INTER_AREA)

# Prepare visualizations for each cluster ---
fig, axs = plt.subplots(1, 4, figsize=(20, 6))

# Panel 1: Original orthophoto
axs[0].imshow(cv2.cvtColor(ortho_resized, cv2.COLOR_BGR2RGB))
axs[0].set_title("Original RGB Orthophoto")
axs[0].axis("off")

# Panels 2–4: One for each cluster
for cid in range(3):
    mask = (label_map == cid).astype(np.uint8)

    # If roi_mask is available, restrict cluster mask to ROI
    mask = mask * mask  # ensure only inside ROI

    # Create colored mask for cluster
    colored_mask = np.zeros_like(ortho_resized)
    for i in range(3):
        colored_mask[:, :, i] = mask * cluster_colors[cid][i]

    # Overlay the color only where mask == 1
    overlay = ortho_resized.copy()
    for i in range(3):
        overlay[:, :, i] = np.where(
            mask == 1,
            cv2.addWeighted(ortho_resized[:, :, i], 1 - alpha, colored_mask[:, :, i], alpha, 0),
            ortho_resized[:, :, i]
        )

    axs[cid + 1].imshow(cv2.cvtColor(overlay, cv2.COLOR_BGR2RGB))
    axs[cid + 1].set_title(f"Cluster {cid} Overlay (in ROI)")
    axs[cid + 1].axis("off")

plt.tight_layout()
plt.show()




