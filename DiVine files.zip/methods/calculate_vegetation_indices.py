import cv2
import numpy as np
#import math
import matplotlib.pyplot as plt

def calculate_ndvi(nir_path, red_path):
    # Load the NIR and Red band images
    nir = cv2.imread(nir_path, cv2.IMREAD_GRAYSCALE)
    red = cv2.imread(red_path, cv2.IMREAD_GRAYSCALE)
    
    # Ensure the images are loaded properly
    if nir is None or red is None:
        print("Error: One or both images not found.")
        return
    
    # Convert images to float32 for calculation
    nir = nir.astype(np.float32)
    red = red.astype(np.float32)
    
    # Calculate NDVI
    ndvi = (nir - red) / (nir + red)
    
    # Normalize NDVI to range 0-255 and convert to uint8
    # ndvi_normalized = cv2.normalize(ndvi, None, 0, 255, cv2.NORM_MINMAX)
    # ndvi_normalized = ndvi_normalized.astype(np.uint8)
    ndvi_normalized = np.clip(ndvi, -1, 1)

    return ndvi_normalized

def calculate_msavi2(nir_path, red_path):
    # Load the NIR and Red band images
    nir = cv2.imread(nir_path, cv2.IMREAD_GRAYSCALE)
    red = cv2.imread(red_path, cv2.IMREAD_GRAYSCALE)
    
    # Ensure the images are loaded properly
    if nir is None or red is None:
        print("Error: One or both images not found.")
        return
    
    # Convert images to float32 for calculation
    nir = nir.astype(np.float32)
    red = red.astype(np.float32)
    
    # Calculate MSAVI2
    msavi2 = (2 * nir + 1 - np.sqrt((2 * nir + 1) ** 2 - 8 * (nir - red))) / 2
 
    # msavi2_normalized = cv2.normalize(msavi2, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    msavi2_normalized = np.clip(msavi2, -1, 1)

    return msavi2_normalized
   

def calculate_ndre(nir_path, red_edge_path):
    # Load the NIR and Red band images
    nir = cv2.imread(nir_path, cv2.IMREAD_GRAYSCALE)
    red_edge = cv2.imread(red_edge_path, cv2.IMREAD_GRAYSCALE)
    
    # Ensure the images are loaded properly
    if nir is None or red_edge is None:
        print("Error: One or both images not found.")
        return
    
    # Convert images to float32 for calculation
    nir = nir.astype(np.float32)
    red_edge = red_edge.astype(np.float32)

    # Calculate NDRE vegetation index
    ndre = (nir - red_edge) / (nir + red_edge + 1e-6)  # Avoid division by zero
  
    #ndre_normalized = cv2.normalize(ndre, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    ndre_normalized = np.clip(ndre, -1, 1)

    return ndre_normalized

def compute_nli(nir_path, red_path):

    nir = cv2.imread(nir_path, cv2.IMREAD_GRAYSCALE)
    red = cv2.imread(red_path, cv2.IMREAD_GRAYSCALE)

    # Ensure the images are loaded properly
    if nir is None or red is None:
        print("Error: One or both images not found.")
        return
    
    # Convert images to float32 for calculation
    nir = nir.astype(np.float32)
    red = red.astype(np.float32)

    #Calculate NLI (Normalized Leaf Index) vegetation index
    L = 0.5
    nli = ((nir - red) / (nir + red + L)) * (1 + L)

    # nli_normalized = cv2.normalize(nli, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    nli_normalized = np.clip(nli, -1, 1)


    return nli_normalized

def main():

    nir_path = '...2024_07_NIR_Plavinci_30m_bl.rgb.TIF'
    red_path = '...2024_07_Red_Plavinci_30m_bl.rgb.TIF'
    red_edge_path = '...2024_07_RedEdge_Plavinci_30m_bl.rgb.TIF'
    
    # Calculate Indices
    ndvi_image = calculate_ndvi(nir_path, red_path)
    msavi2_image = calculate_msavi2(nir_path, red_path)
    ndre_image = calculate_ndre(nir_path,red_edge_path)
    nli_image = compute_nli(nir_path,red_path)
    
    # Display results

    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    cmap = 'RdYlGn' # good for stress display
    # cmap = 'viridis'
    # cmap = 'Spectral'

    indices = [ndvi_image, msavi2_image, ndre_image, nli_image]
    titles = ['NDVI', 'MSAVI2', 'NDRE', 'NLI']

    for ax, index, title in zip(axes.ravel(), indices, titles):
        im = ax.imshow(index, cmap=cmap, vmin=np.nanmin(index), vmax=np.nanmax(index))
        ax.set_title(title)
        ax.axis('off')
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    plt.tight_layout()
    plt.show()

if __name__ == '__main__':
    main()