import cv2
import numpy as np
import matplotlib.pyplot as plt

def select_polygon(event, x, y, flags, param):
    # Mouse callback function to select polygon ROI.
    global points, drawing
    if event == cv2.EVENT_LBUTTONDOWN:
        points.append((x, y))
    elif event == cv2.EVENT_RBUTTONDOWN:
        drawing = False

def create_mask(image, points):
    # Create a binary mask from the polygon points.
    mask = np.zeros(image.shape[:2], dtype=np.uint8)
    if len(points) > 2:
        cv2.fillPoly(mask, [np.array(points, dtype=np.int32)], 255)
    return mask

def crop_to_roi(image, mask):
    # Apply mask to the image and crop to bounding box.
    result = cv2.bitwise_and(image, image, mask=mask)
    x, y, w, h = cv2.boundingRect(mask)
    return result[y:y+h, x:x+w]

def resize_image(image, max_width=1000, max_height=800):
    # Resize image to fit within max dimensions while maintaining aspect ratio.
    h, w = image.shape[:2]
    scale = min(max_width / w, max_height / h, 1)  # Ensure image is only scaled down
    new_w, new_h = int(w * scale), int(h * scale)
    return cv2.resize(image, (new_w, new_h)), scale

def main():
    global points, drawing
    points = []
    drawing = True
    
    # Load TIF image
    image = cv2.imread('...2024_07_NIR_Plavinci_30m_bl.rgb.TIF', cv2.IMREAD_UNCHANGED) # path to your image/map
    resized_image, scale = resize_image(image)
    clone = resized_image.copy()
    
    cv2.namedWindow("Select ROI", cv2.WINDOW_NORMAL)
    cv2.setMouseCallback("Select ROI", select_polygon)
    
    while drawing:
        temp = clone.copy()
        if len(points) > 1:
            for i in range(len(points) - 1):
                cv2.line(temp, points[i], points[i+1], (0, 255, 0), 2)
            if len(points) > 2:
                cv2.line(temp, points[-1], points[0], (0, 255, 0), 2)
        cv2.imshow("Select ROI", temp)
        key = cv2.waitKey(1) & 0xFF
        if key == 27:  # Escape key to exit
            break
    
    cv2.destroyAllWindows()
    
    # Scale points back to original image size
    original_points = [(int(x / scale), int(y / scale)) for x, y in points]
    
    # Create mask and crop
    mask = create_mask(image, original_points)
    cropped_image = crop_to_roi(image, mask)
    
    # Save results
    cv2.imwrite("mask_for_cropping.png", mask)
    cv2.imwrite("ROI_vineyard.tif", cropped_image)
    
    # Display cropped result
    plt.imshow(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
    plt.axis('off')
    plt.title("Cropped ROI")
    plt.show()
    
if __name__ == "__main__":
    main()
