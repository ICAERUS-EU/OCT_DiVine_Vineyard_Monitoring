import cv2
import numpy as np
from PIL import Image

# CONFIGURATION 
image_path = "...2024_Plavinci_Orthomosaic.rgb.TIF"     # Replace with your TIF
resize_factor = 0.2
vine_spacing_px = 44                # Distance between vines
box_size = 40                       # Bounding box size (pixels)

# LOAD AND RESIZE IMAGE
original_img = cv2.imread(image_path)
if original_img is None:
    raise FileNotFoundError("Image not found")

resized_img = cv2.resize(original_img, (0, 0), fx=resize_factor, fy=resize_factor)
clone_for_draw = resized_img.copy()

# CLICK TO DEFINE ROW LINES 
row_lines = []  # List of (start, end) points for each row

def click_lines(event, x, y, flags, param):
    if event == cv2.EVENT_LBUTTONDOWN:
        if len(param["points"]) % 2 == 1:
            cv2.line(clone_for_draw, param["points"][-1], (x, y), (0, 0, 255), 2)
            row_lines.append((param["points"][-1], (x, y)))
        cv2.circle(clone_for_draw, (x, y), 4, (255, 0, 0), -1)
        param["points"].append((x, y))
        cv2.imshow("Draw Vine Rows (2 clicks per row)", clone_for_draw)

cv2.imshow("Draw Vine Rows (2 clicks per row)", clone_for_draw)
click_data = {"points": []}
cv2.setMouseCallback("Draw Vine Rows (2 clicks per row)", click_lines, click_data)

print("Click 2 points for each row line. Press Enter or ESC when done.")
cv2.waitKey(0)
cv2.destroyAllWindows()

# SCALE BACK TO ORIGINAL IMAGE SIZE
row_lines_scaled = [(
    np.array(start, dtype=np.float32) / resize_factor,
    np.array(end, dtype=np.float32) / resize_factor
) for start, end in row_lines]

# DRAW BOXES ALONG EACH ROW LINE 
# Create blank mask (grayscale)
vine_mask = np.zeros(original_img.shape[:2], dtype=np.uint8)
grid_img = original_img.copy()

for start, end in row_lines_scaled:
    direction = end - start
    length = np.linalg.norm(direction)
    if length == 0:
        continue
    unit_vector = direction / length
    num_vines = int(length // vine_spacing_px)

    for i in range(num_vines + 1):
        center = start + i * vine_spacing_px * unit_vector
        cx, cy = int(center[0]), int(center[1])

        top_left = (int(cx - box_size / 2), int(cy - box_size / 2))
        bottom_right = (int(cx + box_size / 2), int(cy + box_size / 2))

        cv2.rectangle(grid_img, top_left, bottom_right, (0, 255, 0), 2)
        # Draw on mask (white box)
        cv2.rectangle(vine_mask, top_left, bottom_right, 255, -1)  # filled white box

# SHOW AND SAVE 
preview = cv2.resize(grid_img, (0, 0), fx=resize_factor, fy=resize_factor)
cv2.imshow("Vine Rows with Bounding Boxes", preview)
cv2.waitKey(0)
cv2.destroyAllWindows()

output_path = "vineyard_rows_boxes.tif"
Image.fromarray(cv2.cvtColor(grid_img, cv2.COLOR_BGR2RGB)).save(output_path)
print(f"Vine boxes saved to: {output_path}")

# Save vine mask
mask_path = "vineyard_vine_mask.tif"
cv2.imwrite(mask_path, vine_mask)
print(f"Mask saved to: {mask_path}")
