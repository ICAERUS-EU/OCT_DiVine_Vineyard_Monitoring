import cv2
import numpy as np
import matplotlib.pyplot as plt

def create_mask_from_file(mask_path):
    # Load a saved mask from file.
    return cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)

def crop_to_roi(image, mask):
    # Apply mask to the image and crop to bounding box.
    result = cv2.bitwise_and(image, image, mask=mask)
    x, y, w, h = cv2.boundingRect(mask)
    return result[y:y+h, x:x+w]

def main():
    # Load new image
    new_image = cv2.imread('...2024_07_NIR_Plavinci_30m_bl.rgb.TIF', cv2.IMREAD_UNCHANGED)
    
    # Load existing mask
    mask = create_mask_from_file('...mask_for_cropping.png')
    
    # Crop new image using the same mask
    cropped_image = crop_to_roi(new_image, mask)
    
    # Save results
    cv2.imwrite("cropped_new_image.TIF", cropped_image)
    
    # Display cropped result
    plt.imshow(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
    plt.axis('off')
    plt.title("Cropped ROI on New Image")
    plt.show()
   
if __name__ == "__main__":
    main()
